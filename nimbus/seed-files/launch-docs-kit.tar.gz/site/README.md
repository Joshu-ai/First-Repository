# Nimbus: a Next.js layout clone of nextjs.org

An original-code rebuild of the structure and behavior of the nextjs.org marketing + docs site,
using a fictional "Nimbus" brand and placeholder text and images. No copy, logos or images from the original.

## Run
```bash
npm install
npm run dev   # http://localhost:3000
```

## Pages
- `/` hero with announcement pill, CTAs, copyable install command, feature grid, templates teaser
- `/docs/[[...slug]]` docs: router dropdown, collapsible sidebar groups, active link, "On this page" TOC with scroll-spy, copy-to-clipboard code blocks, prev/next links (17 pages, statically generated)
- `/blog`, `/blog/[slug]` reverse-chronological post list and post pages
- `/showcase` hero with stat tiles, category filter tabs, paginated card grid with Load More, templates grid
- `/templates`, `/learn`, custom 404

## The "service" (route handlers in `src/app/api`)
- `GET /api/search?q=` searches docs pages and sections, blog posts and pages. Powers the Cmd/Ctrl+K command palette.
- `GET /api/showcase?category=&offset=&limit=` filtered, paginated showcase items.
- `POST /api/newsletter` `{ email }` validates and stores sign-ups (in memory; swap for a DB/ESP).

Theme: system / light / dark switcher in the footer, saved to localStorage, applied before paint (no flash).

All content lives in `src/lib/data.ts`; replace it with MDX or a CMS to make it real.
