import Link from "next/link";
import { CodeBlock } from "@/components/CodeBlock";

const features = [
  { title: "Built-in optimizations", text: "Automatic image, font and script handling for faster pages.", icon: "M13 2 3 14h9l-1 8 10-12h-9z" },
  { title: "Dynamic rendering", text: "Render on the server per request, or ahead of time, per route.", icon: "M4 4h16v6H4zM4 14h16v6H4z" },
  { title: "Streaming", text: "Send UI in pieces so users see content before data finishes.", icon: "M3 12h4l3-8 4 16 3-8h4" },
  { title: "Server functions", text: "Call server code directly from components without writing an API.", icon: "M5 12h14M12 5l7 7-7 7" },
  { title: "Advanced routing", text: "Nested layouts, parallel routes and loading states from the file system.", icon: "M6 3v12M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM18 9a9 9 0 0 1-9 9" },
  { title: "CSS support", text: "Use modules, utility frameworks or CSS-in-JS with zero config.", icon: "M4 4h16l-2 15-6 2-6-2z" },
];

export default function Home() {
  return (
    <>
      <section className="relative overflow-hidden">
        <div className="grid-bg absolute inset-0 -z-10" />
        <div className="mx-auto max-w-5xl px-4 pt-24 pb-20 text-center md:pt-32">
          <Link href="/blog" className="mb-6 inline-flex items-center gap-2 rounded-full border border-line bg-bg-soft px-3 py-1 text-xs text-muted hover:text-fg">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Nimbus 4.14 is out. Read the post →
          </Link>
          <h1 className="text-5xl font-bold tracking-tighter md:text-7xl">The framework<br className="hidden sm:block" /> for building the web</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted md:text-xl">
            Placeholder copy: a short sentence describing what this framework helps teams build, and how quickly.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link href="/docs" className="flex h-11 items-center rounded-md bg-fg px-6 font-medium text-bg hover:opacity-90">Get Started</Link>
            <Link href="/learn" className="flex h-11 items-center rounded-md border border-line px-6 font-medium hover:bg-bg-soft">Learn Nimbus</Link>
          </div>
          <div className="mx-auto mt-8 max-w-sm text-left"><CodeBlock lang="bash" file="Terminal" source="npx create-nimbus-app@latest" /></div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 md:px-6">
        <h2 className="mb-2 text-center text-3xl font-semibold tracking-tight">What&apos;s in Nimbus?</h2>
        <p className="mb-12 text-center text-muted">Everything you need to build fast apps on the web.</p>
        <div className="grid overflow-hidden rounded-xl border border-line sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="border-line p-8 [&:not(:last-child)]:border-b sm:border-r">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="mb-4"><path d={f.icon} /></svg>
              <h3 className="mb-2 font-medium">{f.title}</h3>
              <p className="text-sm text-muted">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 md:grid-cols-2 md:px-6">
          <div>
            <h2 className="text-3xl font-semibold tracking-tight">Start with a template</h2>
            <p className="mt-3 text-muted">Pick a starter, deploy it, and change it to fit.</p>
            <Link href="/templates" className="mt-6 inline-flex h-10 items-center rounded-md border border-line px-4 text-sm hover:bg-bg-soft">Browse templates</Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {["Starter", "Commerce", "AI Chat", "Blog"].map((t, i) => (
              <div key={t} className="aspect-[4/3] rounded-lg border border-line p-4" style={{ background: `linear-gradient(135deg, hsl(${i * 70 + 200} 70% 50% / .18), transparent)` }}>
                <span className="text-sm font-medium">{t}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
