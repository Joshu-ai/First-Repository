import Link from "next/link";
export const metadata = { title: "Learn" };
const chapters = ["Getting started", "Routing", "Styling", "Fetching data", "Mutations", "Caching", "Auth", "Deploying"];
export default function Learn() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      <h1 className="text-4xl font-bold tracking-tight">Learn Nimbus</h1>
      <p className="mt-2 text-muted">A free, hands-on course. Build a small app chapter by chapter.</p>
      <ol className="mt-10 space-y-3">
        {chapters.map((c, i) => (
          <li key={c}>
            <Link href="/docs" className="flex items-center gap-4 rounded-lg border border-line p-4 hover:bg-bg-soft">
              <span className="grid h-8 w-8 place-items-center rounded-full border border-line text-sm">{i + 1}</span>
              <span className="font-medium">{c}</span>
              <span className="ml-auto text-sm text-muted">→</span>
            </Link>
          </li>
        ))}
      </ol>
    </div>
  );
}
