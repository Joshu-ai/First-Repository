import { templates } from "@/lib/data";
export const metadata = { title: "Templates" };
export default function Templates() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-16 md:px-6">
      <h1 className="text-4xl font-bold tracking-tight">Templates</h1>
      <p className="mt-2 text-muted">Jump-start your app with a starter.</p>
      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {templates.map((t, i) => (
          <div key={t.title} className="overflow-hidden rounded-lg border border-line">
            <div className="aspect-[4/3]" style={{ background: `linear-gradient(135deg, hsl(${i * 70 + 200} 70% 50% / .25), transparent)` }} />
            <div className="p-4"><h2 className="font-medium">{t.title}</h2><p className="mt-1 text-sm text-muted">{t.description}</p><code className="mt-3 block font-mono text-xs text-muted">{t.repo}</code></div>
          </div>
        ))}
      </div>
    </div>
  );
}
